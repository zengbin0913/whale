<template>
  <div>
    <my-header></my-header>
    首页1
    <my-footer></my-footer>
  </div>
</template>
<script>
export default {
  
}
</script>
<style scoped>

</style>

